import React from 'react';
import AppNavigator from './navigation';

const App = () => {
  return <AppNavigator />;
};

export default App;
