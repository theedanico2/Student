import React from 'react';
import { Text, View, Image,  Button,  } from 'react-native'

const HelloWorldApp = () => {
  return (
    <View style={{ flex: 1, justifycontent: "center", alignItems: "center", padding: 100, width: "100%"}}>
      <Text style={{ marginBottom: 20, fontSize: 20, color:"green"}}>
        Hello World
      </Text>
    </View>
  );
}

export default HelloWorldApp;