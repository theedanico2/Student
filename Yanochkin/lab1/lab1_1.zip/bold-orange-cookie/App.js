import { Text, Image, SafeAreaView, View, StyleSheet, Button, TouchableOpacity } from 'react-native';
import { MOCK_IMAGE_URL, MOCK_ARTICLE_CONTENT } from './constants/common'

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Журнал Bright</Text>

      <View style={styles.content}>
        <TouchableOpacity style={styles.newsButton}>
          <Text style={styles.newsButtonText}>Новости</Text>
        </TouchableOpacity>

        <View style={styles.article}>
          <Image 
            style={styles.image}
            source={{
              uri: MOCK_ARTICLE_CONTENT.imageUrl 
            }}
          />

          <Text style={styles.articleTitle}>{MOCK_ARTICLE_CONTENT.title}</Text>

          <Text>{MOCK_ARTICLE_CONTENT.previewText}</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  header: {
    textAlign: 'center',
    paddingTop: 40,
    paddingBottom: 10,
    fontWeight: 'bold',
    fontSize: 20
  },
  content: {
    backgroundColor: '#fff',
    flex: 1,
    borderRadius: 8,
    marginHorizontal: 4,
    marginBottom: 8,
    paddingHorizontal: 16,
    paddingTop: 28,
    paddingBottom: 20,
    gap: 40
  },
  newsButton: { 

  },
  articleTitle: {
    fontSize: 25,
    fontWeight: 'bold'
  },
  image: {
    width: '100%',
    height: 150,
    position: 'relative',
  },
  newsButtonText: {
    fontSize: 14,
    color: 'blue'
  },
  article: {
    flex: 1,
    justifyContent: 'space-between',
    paddingBottom: 50
  }
});
