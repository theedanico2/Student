import { Text, Image, SafeAreaView, View, StyleSheet, Button, TouchableOpacity } from 'react-native';
export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>5 книжных новинок октября</Text>
      <Text style={styles.authors}>"Кадиш.com" Натан Ингландер. Издательство "Книжники"</Text>
      <Text style={styles.description}>Ироничная новелла Натана Ингландера, две личные истории культовой Патти Смит, репортаж британской журналистики о будущем человечества, дебютный роман Оушена Вуонга и журналистское расследование о создании "Моссада". В нашей подборке рассказываем о пяти захватывающих книжных новинках, которые достойны того, чтобы появиться на ваших полках</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  authors: {
    backgroundColor: '#b3b3b3',
    padding: 10,
    fontSize: 16,
    textAlign: 'center',
    flex: 1
  },
  description: {
    backgroundColor: '#8a8a8a',
    textAlign: 'center',
    padding: 10,
    fontSize: 14,
    flex: 5
  }
});
