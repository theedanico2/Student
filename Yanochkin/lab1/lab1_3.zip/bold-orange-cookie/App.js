import { Text, Image, SafeAreaView, TextInput, View, StyleSheet, Button, Alert } from 'react-native';
export default function App() {
  const onButtonPress = () => {
    Alert.alert('Attention', 'Very important alert message')
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.form}>
        <Text>login</Text>
        <TextInput style={styles.input} />
        <Text style={styles.passwordLabel}>password</Text>
        <TextInput style={[styles.input, styles.passwordInput]} />

        <Button onPress={onButtonPress} title="Log In" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)',
    height: 25,
  },
  passwordInput: {
    marginBottom: 16
  },
  passwordLabel: {
    marginTop: 5
  },
  form: {
    marginHorizontal: 20,
    background: 'rgba(0,0,0,0.03)',
    padding: 20,
    borderRadius: 8
  },
});
